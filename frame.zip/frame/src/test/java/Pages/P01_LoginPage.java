package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class P01_LoginPage {
    WebDriver driver;
    public P01_LoginPage(WebDriver driver){
        this.driver = driver ;
        PageFactory.initElements(driver,this);

    }

    public WebElement emailPOM(){
        return driver.findElement(By.className("z-TextBox"));
    }
   // cssSelector(".z-TextBox"
    public WebElement passwordPOM(){
        return driver.findElement(By.className("gwt-PasswordTextBox"));
    }
    // cssSelector(".gwt-PasswordTextBox"
    public WebElement Login_ButtonPOM(){
        return   driver.findElement(By.xpath("//button[text()='Login']"));
    }
    //By.cssSelector(".z-TextButton:nth-child(2)"

    public WebElement SelectSitePOM(){
        return   driver.findElement(By.cssSelector(".z-FlowHorizontalPanel:nth-child(4) > .z-ListBox"));
    }
    /*


    public WebElement SelectSchoolPOM(){
        return   driver.findElement(By.xpath("//td/div/span"));
    }

    public WebElement AssigneCoursePOM(){
        return   driver.findElement(By.xpath("//div[5]/table/tbody/tr/td[2]/div/table/tbody/tr/td[4]/select"));
    }//option[@value='Medeya Saqer Ghanim Ali Almarri (289339)'])[2]"

    public WebElement MemberTabPOM(){
        return   driver.findElement(By.xpath("//button[text()='Members']"));
    }

*/


/*
    public void LoginSteps( String email, String password){
        //enter username using POM
        emailPOM().clear();
        emailPOM().sendKeys(email);
        //enter password using POM
        passwordPOM().sendKeys(password);

    }

 */
}
