package stepDefintions;

import Pages.P01_LoginPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


public class D01_LoginStepDefinition {
    WebDriver driver =Hooks.driver;
    P01_LoginPage login = new P01_LoginPage(driver);

    WebDriverWait wait = new WebDriverWait( driver , Duration.ofSeconds(10));




    @When("user navigate to login page")
    public void user_navigate ()  {
        driver.navigate().to("https://sis-test.itworxedu.net/SIS-TEST04/ZLMSWeb.html?login=1&locale=default");

    }

    @And("user enter Email and password")
    public void userEnterEmailAndPassword() {
        login.emailPOM().sendKeys("administrator");
        login.passwordPOM().sendKeys("misk");
    }

/*
    @And("^user enter \"(.*)\" and \"(.*)\"$")
    public void valid_data(String email,String password){
        login.LoginSteps(email,password);

    }

*/
    @Then("user click on login button")
    public void login_button() {
     login.Login_ButtonPOM().click();
    }

    @And("user select site")
    public void select_site()  {
       wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".z-FlowHorizontalPanel:nth-child(4) > .z-ListBox")));

        Select dropdown=new Select(login.SelectSitePOM());
        dropdown.selectByIndex(3);
    }




/*
    //compare actual with expected result
    @Then("user could login successfully")
    public void success_login(){
        Assert.assertEquals("https://demo.nopcommerce.com/",driver.getCurrentUrl());

    }

*/
}
